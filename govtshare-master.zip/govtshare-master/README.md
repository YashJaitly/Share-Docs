# sharedoc

•online sharing of documents
• Developed interface like google doc supporting multiuser functionality
Using socket.io
• Implemented CRUD in moongose.js (MongoDB) for file system

## Installation

npm install 
node app.js

## Usage

to be written by author soon

## Demo
https://drive.google.com/file/d/178snOQowNUrhDlmeRJWcFOdbfdwGoR6D/view?usp=drivesdk

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to test as appropriate before pull request.

## License
open source software 